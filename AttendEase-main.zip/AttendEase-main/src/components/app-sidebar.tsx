"use client";

import { usePathname } from "next/navigation";
import {
  BarChart3,
  BookUser,
  CalendarCheck,
  Database,
  LayoutGrid,
  Users,
} from "lucide-react";

import {
  Sidebar,
  SidebarHeader,
  SidebarContent,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarFooter,
  SidebarTrigger,
} from "@/components/ui/sidebar";

const menuItems = [
  {
    href: "/dashboard",
    label: "Dashboard",
    icon: LayoutGrid,
  },
  {
    href: "/students",
    label: "Students",
    icon: Users,
  },
  {
    href: "/attendance",
    label: "Attendance",
    icon: CalendarCheck,
  },
  {
    href: "/reports",
    label: "Reports",
    icon: BarChart3,
  },
  {
    href: "/data",
    label: "Data",
    icon: Database,
  },
];

export function AppSidebar() {
  const pathname = usePathname();

  return (
    <Sidebar>
      <SidebarHeader>
        <div className="flex items-center gap-2 p-2">
          <BookUser className="text-primary" size={24} />
          <h1 className="text-xl font-bold text-sidebar-foreground">
            AttendEase
          </h1>
        </div>
      </SidebarHeader>
      <SidebarContent>
        <SidebarMenu>
          {menuItems.map((item) => (
            <SidebarMenuItem key={item.href}>
              <SidebarMenuButton
                asChild
                isActive={pathname === item.href}
                tooltip={item.label}
              >
                <a href={item.href}>
                  <item.icon />
                  <span>{item.label}</span>
                </a>
              </SidebarMenuButton>
            </SidebarMenuItem>
          ))}
        </SidebarMenu>
      </SidebarContent>
      <SidebarFooter className="hidden md:flex">
         <SidebarMenu>
            <SidebarMenuItem>
                <div className="flex w-full items-center gap-2 rounded-md p-2 text-left text-sm">
                    <SidebarTrigger />
                    <span className="flex-1">Collapse</span>
                </div>
            </SidebarMenuItem>
        </SidebarMenu>
      </SidebarFooter>
    </Sidebar>
  );
}
