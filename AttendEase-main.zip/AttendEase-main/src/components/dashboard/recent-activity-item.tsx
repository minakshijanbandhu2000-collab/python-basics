"use client";

import { useState, useEffect } from 'react';
import { formatDistanceToNow } from 'date-fns';
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import type { AttendanceRecord, Student } from '@/lib/types';

interface RecentActivityItemProps {
  record: AttendanceRecord;
  student: Student;
}

export function RecentActivityItem({ record, student }: RecentActivityItemProps) {
  const [timeAgo, setTimeAgo] = useState('');

  useEffect(() => {
    setTimeAgo(formatDistanceToNow(new Date(record.date), { addSuffix: true }));
  }, [record.date]);

  const statusBadge = {
    present: <Badge variant="default" className="bg-green-600">Present</Badge>,
    absent: <Badge variant="destructive">Absent</Badge>,
    late: <Badge variant="secondary" className="bg-yellow-500 text-black">Late</Badge>,
    excused: <Badge variant="outline">Excused</Badge>
  }[record.status];

  return (
    <div className="flex items-center gap-4">
      <Avatar className="h-9 w-9">
        <AvatarImage src={student.photoUrl} alt={student.name} />
        <AvatarFallback>{student.name.charAt(0)}</AvatarFallback>
      </Avatar>
      <div className="flex-1">
        <p className="text-sm font-medium leading-none">{student.name}</p>
        <p className="text-sm text-muted-foreground">{timeAgo || <>&nbsp;</>}</p>
      </div>
      {statusBadge}
    </div>
  );
}
