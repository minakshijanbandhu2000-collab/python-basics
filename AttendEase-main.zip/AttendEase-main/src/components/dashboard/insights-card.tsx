"use client";

import { useState } from "react";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Lightbulb, Loader2 } from "lucide-react";
import { generateInsightsAction } from "@/app/actions";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

export function InsightsCard() {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<{ summary?: string; error?: string } | null>(null);

  const handleGenerate = async () => {
    setLoading(true);
    setResult(null);
    const response = await generateInsightsAction();
    setResult(response);
    setLoading(false);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Lightbulb className="text-yellow-500" />
          AI Attendance Insights
        </CardTitle>
        <CardDescription>
          Leverage AI to analyze attendance data and get a summary of trends and potential issues.
        </CardDescription>
      </CardHeader>
      <CardContent>
        {result?.summary && (
          <Alert>
            <AlertTitle>Generated Summary</AlertTitle>
            <AlertDescription>
              <p className="whitespace-pre-wrap">{result.summary}</p>
            </AlertDescription>
          </Alert>
        )}
        {result?.error && (
            <Alert variant="destructive">
                <AlertTitle>Error</AlertTitle>
                <AlertDescription>{result.error}</AlertDescription>
            </Alert>
        )}
      </CardContent>
      <CardFooter>
        <Button onClick={handleGenerate} disabled={loading}>
          {loading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Generating...
            </>
          ) : (
            "Generate Insights"
          )}
        </Button>
      </CardFooter>
    </Card>
  );
}
