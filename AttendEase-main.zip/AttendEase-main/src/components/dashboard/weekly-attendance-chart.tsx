"use client"

import * as React from "react"
import { Bar, BarChart, CartesianGrid, XAxis, YAxis, Tooltip, Legend } from "recharts"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import {
  ChartContainer,
} from "@/components/ui/chart"
import type { AttendanceRecord } from "@/lib/types"
import { subDays, format } from "date-fns"

interface WeeklyAttendanceChartProps {
  attendance: AttendanceRecord[]
}

export function WeeklyAttendanceChart({ attendance }: WeeklyAttendanceChartProps) {
  const chartData = React.useMemo(() => {
    const dataByDay: { [key: string]: { present: number; absent: number } } = {};
    const today = new Date();
    
    for (let i = 6; i >= 0; i--) {
      const date = subDays(today, i);
      const dateString = format(date, "yyyy-MM-dd");
      const dayName = format(date, "EEE");
      dataByDay[dateString] = { present: 0, absent: 0 };

      const recordsForDay = attendance.filter(a => a.date === dateString);
      recordsForDay.forEach(record => {
        if (record.status === 'present' || record.status === 'late') {
          dataByDay[dateString].present++;
        } else if (record.status === 'absent') {
          dataByDay[dateString].absent++;
        }
      });
    }

    return Object.entries(dataByDay).map(([date, counts]) => ({
      date: format(new Date(date), "MMM d"),
      present: counts.present,
      absent: counts.absent,
    }));
  }, [attendance]);
  
  const chartConfig = {
      present: {
        label: "Present",
        color: "hsl(var(--chart-1))",
      },
      absent: {
        label: "Absent",
        color: "hsl(var(--destructive))",
      },
  } satisfies React.ComponentProps<typeof ChartContainer>["config"]


  return (
    <Card>
      <CardHeader>
        <CardTitle>Weekly Attendance Overview</CardTitle>
        <CardDescription>Attendance trends for the last 7 days.</CardDescription>
      </CardHeader>
      <CardContent>
        <ChartContainer config={chartConfig} className="min-h-[200px] w-full">
            <BarChart data={chartData} margin={{ top: 20, right: 20, bottom: 5, left: 0 }}>
                <CartesianGrid vertical={false} />
                <XAxis
                    dataKey="date"
                    tickLine={false}
                    tickMargin={10}
                    axisLine={false}
                />
                 <YAxis
                    tickLine={false}
                    axisLine={false}
                    tickMargin={10}
                    allowDecimals={false}
                />
                <Tooltip
                    cursor={false}
                    contentStyle={{
                      background: "hsl(var(--card))",
                      border: "1px solid hsl(var(--border))",
                      borderRadius: "var(--radius)",
                    }}
                 />
                <Legend />
                <Bar dataKey="present" fill="var(--color-present)" radius={4} />
                <Bar dataKey="absent" fill="var(--color-absent)" radius={4} />
            </BarChart>
        </ChartContainer>
      </CardContent>
    </Card>
  )
}
