"use client";

import * as React from "react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Download } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import type { Student, AttendanceRecord } from "@/lib/types";
import { getStudentsAction, getAttendanceAction } from "@/app/actions";
import { exportToCsv } from "@/lib/utils";
import { Input } from "@/components/ui/input";

const months = [
  { value: "0", label: "January" }, { value: "1", label: "February" },
  { value: "2", label: "March" }, { value: "3", label: "April" },
  { value: "4", label: "May" }, { value: "5", label: "June" },
  { value: "6", label: "July" }, { value: "7", label: "August" },
  { value: "8", label: "September" }, { value: "9", label: "October" },
  { value: "10", label: "November" }, { value: "11", label: "December" },
];

const classNames = [
  "all",
  "1st Sem",
  "2nd Sem",
  "3rd Sem",
  "4th Sem",
  "5th Sem",
  "6th Sem",
  "7th Sem",
  "8th Sem",
];

export default function ReportsPage() {
  const [students, setStudents] = React.useState<Student[]>([]);
  const [attendance, setAttendance] = React.useState<AttendanceRecord[]>([]);
  const [selectedClass, setSelectedClass] = React.useState<string>("all");
  const [selectedMonth, setSelectedMonth] = React.useState<string | undefined>();
  const [subject, setSubject] = React.useState<string>("");

  React.useEffect(() => {
    setSelectedMonth(new Date().getMonth().toString());
    getStudentsAction().then(setStudents);
    getAttendanceAction().then(setAttendance);
  }, []);

  const reportData = React.useMemo(() => {
    if (selectedMonth === undefined) return [];

    const targetMonth = parseInt(selectedMonth, 10);
    const year = new Date().getFullYear(); 

    const daysInMonth = new Date(year, targetMonth + 1, 0).getDate();
    const classStudents = selectedClass === "all" ? students : students.filter(s => s.class === selectedClass);

    return classStudents.map(student => {
      const studentAttendance = attendance.filter(a => 
        a.studentId === student.id && 
        new Date(a.date).getMonth() === targetMonth &&
        (!subject || (a.subject && a.subject.toLowerCase().includes(subject.toLowerCase())))
      );

      const totalRecords = studentAttendance.length;
      
      const presentDays = studentAttendance.filter(a => a.status === 'present' || a.status === 'late').length;
      
      const totalDays = totalRecords > 0 ? totalRecords : daysInMonth;

      const percentage = totalDays > 0 ? (presentDays / totalDays) * 100 : 0;
      
      return {
        id: student.id,
        name: student.name,
        class: student.class,
        percentage,
        presentDays,
        totalDays: totalDays
      };
    });
  }, [students, attendance, selectedClass, selectedMonth, subject]);

  const overallStats = React.useMemo(() => {
    const totalPercentage = reportData.reduce((sum, item) => sum + item.percentage, 0);
    const average = reportData.length > 0 ? totalPercentage / reportData.length : 0;
    return { average };
  }, [reportData]);

  const getProgressColor = (percentage: number) => {
    if (percentage > 90) return "bg-green-500";
    if (percentage > 75) return "bg-yellow-500";
    return "bg-red-500";
  };
  
  const handleExport = () => {
    if (selectedMonth === undefined) return;
    const rows = [
      ["Student Name", "Class", "Attendance %", "Present Days", "Total Days"],
      ...reportData.map(r => [r.name, r.class, r.percentage.toFixed(2), r.presentDays, r.totalDays])
    ];
    exportToCsv(`attendance-report-${months[parseInt(selectedMonth, 10)].label}-${selectedClass}.csv`, rows);
  }

  return (
    <div className="flex flex-col gap-8">
      <header>
        <h1 className="text-3xl font-bold tracking-tight">Attendance Reports</h1>
        <p className="text-muted-foreground">Generate and view monthly attendance reports.</p>
      </header>

      <div className="flex flex-col md:flex-row gap-4">
        <Select value={selectedMonth} onValueChange={setSelectedMonth}>
          <SelectTrigger className="w-full md:w-[180px]">
            <SelectValue placeholder="Select Month" />
          </SelectTrigger>
          <SelectContent>
            {months.map((m) => (
              <SelectItem key={m.value} value={m.value}>{m.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={selectedClass} onValueChange={setSelectedClass}>
          <SelectTrigger className="w-full md:w-[180px]">
            <SelectValue placeholder="Select Class" />
          </SelectTrigger>
          <SelectContent>
            {classNames.map((c) => (
              <SelectItem key={c} value={c}>{c === 'all' ? 'All Classes' : c}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        
        <Input 
          placeholder="Filter by Subject Name..."
          className="w-full md:w-[220px]"
          value={subject}
          onChange={(e) => setSubject(e.target.value)}
        />

        <Button className="ml-auto" onClick={handleExport}>
            <Download className="mr-2 h-4 w-4" />
            Export CSV
        </Button>
      </div>
      
      <div className="grid gap-4 md:grid-cols-3">
        <Card>
            <CardHeader><CardTitle>Overall Attendance</CardTitle></CardHeader>
            <CardContent>
                <p className="text-3xl font-bold">{overallStats.average.toFixed(1)}%</p>
                <p className="text-sm text-muted-foreground">Average for selected group</p>
            </CardContent>
        </Card>
      </div>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Student Name</TableHead>
                <TableHead>Class</TableHead>
                <TableHead className="w-[40%]">Attendance Percentage</TableHead>
                <TableHead className="text-right">Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {reportData.length > 0 ? (
                reportData.map((item) => (
                  <TableRow key={item.id}>
                    <TableCell className="font-medium">{item.name}</TableCell>
                    <TableCell>{item.class}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-4">
                        <Progress value={item.percentage} indicatorClassName={getProgressColor(item.percentage)} className="h-2" />
                        <span className="font-mono text-sm">{item.percentage.toFixed(1)}%</span>
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                        {item.percentage > 90 ? <Badge variant="default" className="bg-green-600">Excellent</Badge> : item.percentage > 75 ? <Badge variant="secondary" className="bg-yellow-500 text-black">Good</Badge> : <Badge variant="destructive">Needs Attention</Badge>}
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={4} className="h-24 text-center">
                    No data for the selected criteria.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
