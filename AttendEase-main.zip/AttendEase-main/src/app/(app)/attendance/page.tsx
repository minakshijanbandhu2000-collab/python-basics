"use client";

import * as React from "react";
import { format } from "date-fns";
import { Calendar as CalendarIcon, Check, Loader2, PlusCircle } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import type { Student, AttendanceStatus } from "@/lib/types";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { StudentForm } from "../students/_components/student-form";
import { updateAttendanceAction, getStudentsAction, getAttendanceByDateAction } from "@/app/actions";
import { Input } from "@/components/ui/input";

const classNames = [
  "all",
  "1st Sem",
  "2nd Sem",
  "3rd Sem",
  "4th Sem",
  "5th Sem",
  "6th Sem",
  "7th Sem",
  "8th Sem",
];

export default function AttendancePage() {
  const { toast } = useToast();
  const [date, setDate] = React.useState<Date | undefined>();
  const [selectedClass, setSelectedClass] = React.useState<string>("all");
  const [subject, setSubject] = React.useState<string>("");
  const [students, setStudents] = React.useState<Student[]>([]);
  const [attendance, setAttendance] = React.useState<Record<string, AttendanceStatus>>({});
  const [isSaving, setIsSaving] = React.useState(false);
  const [isFormOpen, setIsFormOpen] = React.useState(false);
  
  const refreshData = async (newDate? : Date) => {
    const fetchDate = newDate || date;
    if (!fetchDate) return;
    const freshStudents = await getStudentsAction();
    setStudents(freshStudents);
    const dateString = format(fetchDate, "yyyy-MM-dd");
    const freshAttendance = await getAttendanceByDateAction(dateString);

    const newAttendance: Record<string, AttendanceStatus> = {};
    for (const record of freshAttendance) {
        if(record.subject === subject) {
            newAttendance[record.studentId] = record.status;
        }
    }
    setAttendance(newAttendance);
  };
  
  React.useEffect(() => {
    setDate(new Date());
  }, []);

  React.useEffect(() => {
    if (date) {
        refreshData();
    }
  }, [date, selectedClass, subject]);

  
  const filteredStudents = React.useMemo(() => {
    if (selectedClass === "all") return students;
    return students.filter((s) => s.class === selectedClass);
  }, [students, selectedClass]);

  const handleStatusChange = (studentId: string, status: AttendanceStatus) => {
    setAttendance((prev) => ({ ...prev, [studentId]: status }));
  };
  
  const handleMarkAllPresent = () => {
    if (!subject) {
      toast({ title: "Error", description: "Please enter a subject first.", variant: "destructive" });
      return;
    }
    const newAttendance = { ...attendance };
    filteredStudents.forEach(student => {
        newAttendance[student.id] = 'present';
    });
    setAttendance(newAttendance);
  }

  const handleSave = async () => {
    if (!subject) {
      toast({ title: "Error", description: "Please enter a subject first.", variant: "destructive" });
      return;
    }
    if (!date) {
        toast({ title: "Error", description: "Please select a date first.", variant: "destructive" });
        return;
    }
    setIsSaving(true);
    const dateString = format(date, "yyyy-MM-dd");
    try {
      const promises = filteredStudents
        .map(student => {
          const status = attendance[student.id] || 'present';
          return updateAttendanceAction(student.id, dateString, status, subject);
        });

      await Promise.all(promises);

      toast({
        title: "Success",
        description: `Attendance records for ${subject} have been saved.`,
      });
    } catch (error) {
      console.error("Failed to save attendance", error)
      toast({
        title: "Error",
        description: "Failed to save attendance.",
        variant: "destructive",
      });
    } finally {
      setIsSaving(false);
    }
  };
  
  const onFormFinished = () => {
    setIsFormOpen(false);
    refreshData();
  }

  const studentForForm = selectedClass !== 'all' ? { class: selectedClass } as Partial<Student> : null;

  return (
    <div className="flex flex-col gap-8">
      <header>
        <h1 className="text-3xl font-bold tracking-tight">Daily Attendance</h1>
        <p className="text-muted-foreground">Mark student attendance for the selected day and class.</p>
      </header>

      <div className="flex flex-col md:flex-row gap-4">
        <Popover>
          <PopoverTrigger asChild>
            <Button
              variant={"outline"}
              className={cn("w-full md:w-[280px] justify-start text-left font-normal", !date && "text-muted-foreground")}
            >
              <CalendarIcon className="mr-2 h-4 w-4" />
              {date ? format(date, "PPP") : <span>Pick a date</span>}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0">
            <Calendar mode="single" selected={date} onSelect={(d) => d && setDate(d)} initialFocus />
          </PopoverContent>
        </Popover>

        <Select value={selectedClass} onValueChange={setSelectedClass}>
          <SelectTrigger className="w-full md:w-[180px]">
            <SelectValue placeholder="Select Class" />
          </SelectTrigger>
          <SelectContent>
            {classNames.map((c) => (
              <SelectItem key={c} value={c}>{c === 'all' ? 'All Classes' : c}</SelectItem>
            ))}
          </SelectContent>
        </Select>

         <Input 
            placeholder="Enter Subject Name"
            className="w-full md:w-[220px]"
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
        />

        <Button variant="outline" onClick={() => setIsFormOpen(true)} disabled={selectedClass === 'all'}>
            <PlusCircle className="mr-2 h-4 w-4" />
            Add Student
        </Button>
        
        <div className="flex gap-2 ml-auto">
            <Button variant="outline" onClick={handleMarkAllPresent}>Mark All Present</Button>
            <Button onClick={handleSave} disabled={isSaving}>
              {isSaving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Check className="mr-2 h-4 w-4" />}
              Save
            </Button>
        </div>
      </div>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[80px]">Photo</TableHead>
                <TableHead>Name</TableHead>
                <TableHead>Class</TableHead>
                <TableHead className="text-right w-[400px]">Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredStudents.length > 0 ? (
                filteredStudents.map((student) => (
                  <TableRow key={student.id}>
                    <TableCell>
                      <Avatar>
                        <AvatarImage src={student.photoUrl} alt={student.name} />
                        <AvatarFallback>{student.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                    </TableCell>
                    <TableCell className="font-medium">{student.name}</TableCell>
                    <TableCell>{student.class}</TableCell>
                    <TableCell className="text-right">
                      <RadioGroup
                        defaultValue="present"
                        className="flex justify-end gap-4"
                        value={attendance[student.id] || 'present'}
                        onValueChange={(value: AttendanceStatus) => handleStatusChange(student.id, value)}
                        disabled={!subject}
                      >
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="present" id={`present-${student.id}`} />
                          <Label htmlFor={`present-${student.id}`}>Present</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="absent" id={`absent-${student.id}`} />
                          <Label htmlFor={`absent-${student.id}`}>Absent</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="late" id={`late-${student.id}`} />
                          <Label htmlFor={`late-${student.id}`}>Late</Label>
                        </div>
                        <div className="flex items-center space-x-2">
                          <RadioGroupItem value="excused" id={`excused-${student.id}`} />
                          <Label htmlFor={`excused-${student.id}`}>Excused</Label>
                        </div>
                      </RadioGroup>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={4} className="h-24 text-center">
                    No students found for this class.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
      
      <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
        <DialogContent className="sm:max-w-[625px]">
          <DialogHeader>
            <DialogTitle>Add New Student</DialogTitle>
            <DialogDescription>
              Fill in the details to create a new student profile for class {selectedClass}.
            </DialogDescription>
          </DialogHeader>
          <StudentForm student={studentForForm} onFinished={onFormFinished} />
        </DialogContent>
      </Dialog>
    </div>
  );
}
