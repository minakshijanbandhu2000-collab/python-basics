"use client"

import * as React from "react";
import { useRouter, useSearchParams } from "next/navigation";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface ClassFilterProps {
  classes: string[];
  selectedClass: string;
}

export function ClassFilter({ classes, selectedClass }: ClassFilterProps) {
  const router = useRouter();
  const searchParams = useSearchParams();

  const handleClassChange = (newClass: string) => {
    const params = new URLSearchParams(searchParams.toString());
    if (newClass === "all") {
      params.delete("class");
    } else {
      params.set("class", newClass);
    }
    router.push(`?${params.toString()}`);
  };

  return (
    <div className="flex items-center gap-4">
        <p className="text-sm font-medium">Class:</p>
        <Select value={selectedClass} onValueChange={handleClassChange}>
            <SelectTrigger className="w-full md:w-[240px]">
                <SelectValue placeholder="Select Class" />
            </SelectTrigger>
            <SelectContent>
                {classes.map((c) => (
                <SelectItem key={c} value={c}>
                    {c === "all" ? "All Classes" : c}
                </SelectItem>
                ))}
            </SelectContent>
        </Select>
    </div>
  );
}
