"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import type { Student } from "@/lib/types";
import { addStudentAction, updateStudentAction } from "@/app/actions";
import { Loader2 } from "lucide-react";

const formSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters."),
  email: z.string().email("Invalid email address."),
  phone: z.string().min(10, "Phone number seems too short."),
  class: z.string().min(1, "Class is required."),
  parentName: z.string().min(2, "Parent's name is required."),
  parentPhone: z.string().min(10, "Parent's phone number seems too short."),
  dob: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Date must be in YYYY-MM-DD format."),
  address: z.string().min(5, "Address is required."),
  emergencyContactName: z.string().min(2, "Emergency contact name is required."),
  emergencyContactPhone: z.string().min(10, "Emergency contact phone seems too short."),
  bloodGroup: z.string().min(1, "Blood group is required."),
  erpNumber: z.string().min(1, "ERP Number is required."),
});

type StudentFormValues = z.infer<typeof formSchema>;

interface StudentFormProps {
  student: Partial<Student> | null;
  onFinished: () => void;
}

export function StudentForm({ student, onFinished }: StudentFormProps) {
  const { toast } = useToast();
  const form = useForm<StudentFormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: student?.name || "",
      email: student?.email || "",
      phone: student?.phone || "",
      class: student?.class || "",
      parentName: student?.parentName || "",
      parentPhone: student?.parentPhone || "",
      dob: student?.dob || "",
      address: student?.address || "",
      emergencyContactName: student?.emergencyContactName || "",
      emergencyContactPhone: student?.emergencyContactPhone || "",
      bloodGroup: student?.bloodGroup || "",
      erpNumber: student?.erpNumber || "",
    },
  });
  
  const { isSubmitting } = form.formState;

  async function onSubmit(values: StudentFormValues) {
    try {
      if (student?.id) {
        await updateStudentAction(student.id, values);
        toast({ title: "Success", description: "Student profile updated." });
      } else {
        await addStudentAction(values);
        toast({ title: "Success", description: "New student added." });
        form.reset();
      }
      onFinished();
    } catch (error) {
      toast({
        title: "Error",
        description: "An error occurred. Please try again.",
        variant: "destructive",
      });
    }
  }

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField control={form.control} name="name" render={({ field }) => (
              <FormItem>
                <FormLabel>Full Name</FormLabel>
                <FormControl><Input placeholder="John Doe" {...field} /></FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField control={form.control} name="erpNumber" render={({ field }) => (
              <FormItem>
                <FormLabel>ERP Number</FormLabel>
                <FormControl><Input placeholder="EN123456" {...field} /></FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField control={form.control} name="email" render={({ field }) => (
              <FormItem>
                <FormLabel>Email</FormLabel>
                <FormControl><Input placeholder="john.doe@example.com" {...field} /></FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField control={form.control} name="phone" render={({ field }) => (
              <FormItem>
                <FormLabel>Phone</FormLabel>
                <FormControl><Input placeholder="555-123-4567" {...field} /></FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField control={form.control} name="class" render={({ field }) => (
              <FormItem>
                <FormLabel>Class</FormLabel>
                <FormControl><Input placeholder="10A" {...field} /></FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField control={form.control} name="dob" render={({ field }) => (
              <FormItem>
                <FormLabel>Date of Birth</FormLabel>
                <FormControl><Input placeholder="YYYY-MM-DD" {...field} type="date" /></FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
           <FormField control={form.control} name="bloodGroup" render={({ field }) => (
              <FormItem>
                <FormLabel>Blood Group</FormLabel>
                <FormControl><Input placeholder="e.g. O+" {...field} /></FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
           <FormField control={form.control} name="address" render={({ field }) => (
              <FormItem>
                <FormLabel>Address</FormLabel>
                <FormControl><Input placeholder="123 Main St, Anytown" {...field} /></FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField control={form.control} name="parentName" render={({ field }) => (
              <FormItem>
                <FormLabel>Parent&apos;s Name</FormLabel>
                <FormControl><Input placeholder="Jane Doe" {...field} /></FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          <FormField control={form.control} name="parentPhone" render={({ field }) => (
              <FormItem>
                <FormLabel>Parent&apos;s Phone</FormLabel>
                <FormControl><Input placeholder="555-987-6543" {...field} /></FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
           <FormField control={form.control} name="emergencyContactName" render={({ field }) => (
              <FormItem>
                <FormLabel>Emergency Contact Name</FormLabel>
                <FormControl><Input placeholder="Emergency Contact" {...field} /></FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
           <FormField control={form.control} name="emergencyContactPhone" render={({ field }) => (
              <FormItem>
                <FormLabel>Emergency Contact Phone</FormLabel>
                <FormControl><Input placeholder="555-555-5555" {...field} /></FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>
        <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={onFinished}>Cancel</Button>
            <Button type="submit" disabled={isSubmitting}>
                {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                {student?.id ? 'Save Changes' : 'Create Student'}
            </Button>
        </div>
      </form>
    </Form>
  );
}
