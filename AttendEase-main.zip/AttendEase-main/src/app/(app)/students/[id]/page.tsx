
import { notFound } from 'next/navigation';
import { db } from '@/lib/data';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import { ArrowLeft, Mail, Phone, User, Calendar, Home, AlertTriangle, Droplets, Hash } from 'lucide-react';

export default async function StudentDetailPage({ params }: { params: { id: string } }) {
  const student = await db.getStudentById(params.id);

  if (!student) {
    notFound();
  }

  return (
    <div className="flex flex-col gap-8">
      <header className="flex items-center justify-between">
        <div className="flex items-center gap-4">
            <Button asChild variant="outline" size="icon">
                <Link href="/students">
                    <ArrowLeft />
                    <span className="sr-only">Back to students</span>
                </Link>
            </Button>
            <h1 className="text-3xl font-bold tracking-tight">Student Profile</h1>
        </div>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-1">
          <Card>
            <CardContent className="p-6 flex flex-col items-center text-center">
              <Avatar className="w-24 h-24 mb-4">
                <AvatarImage src={student.photoUrl} alt={student.name} />
                <AvatarFallback>{student.name.charAt(0)}</AvatarFallback>
              </Avatar>
              <h2 className="text-2xl font-bold">{student.name}</h2>
              <p className="text-muted-foreground">{student.class}</p>
              <p className="text-sm text-muted-foreground mt-2">ERP: {student.erpNumber}</p>
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-2 space-y-8">
          <Card>
            <CardHeader>
              <CardTitle>Contact Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-4">
                <Mail className="w-5 h-5 text-muted-foreground" />
                <span>{student.email}</span>
              </div>
              <div className="flex items-center gap-4">
                <Phone className="w-5 h-5 text-muted-foreground" />
                <span>{student.phone}</span>
              </div>
               <div className="flex items-center gap-4">
                <Home className="w-5 h-5 text-muted-foreground" />
                <span>{student.address}</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Personal Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
                <div className="flex items-center gap-4">
                    <Calendar className="w-5 h-5 text-muted-foreground" />
                    <span>Date of Birth: {student.dob}</span>
                </div>
                 <div className="flex items-center gap-4">
                    <Droplets className="w-5 h-5 text-muted-foreground" />
                    <span>Blood Group: {student.bloodGroup}</span>
                </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Parent & Emergency Contact</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center gap-4">
                <User className="w-5 h-5 text-muted-foreground" />
                <span>Parent: {student.parentName}</span>
              </div>
              <div className="flex items-center gap-4">
                <Phone className="w-5 h-5 text-muted-foreground" />
                <span>Parent's Phone: {student.parentPhone}</span>
              </div>
              <div className="flex items-center gap-4 mt-4 pt-4 border-t">
                <AlertTriangle className="w-5 h-5 text-destructive" />
                <span className='font-semibold'>Emergency: {student.emergencyContactName}</span>
              </div>
               <div className="flex items-center gap-4">
                <Phone className="w-5 h-5 text-muted-foreground" />
                <span>Emergency Phone: {student.emergencyContactPhone}</span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
