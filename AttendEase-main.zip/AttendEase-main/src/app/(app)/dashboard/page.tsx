
import { Users, CalendarCheck, Percent, Activity } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { InsightsCard } from "@/components/dashboard/insights-card";
import { db } from "@/lib/data";
import { WeeklyAttendanceChart } from "@/components/dashboard/weekly-attendance-chart";
import { RecentActivityItem } from "@/components/dashboard/recent-activity-item";

export default async function DashboardPage() {
  const students = await db.getStudents();
  const attendance = await db.getAttendance();

  const totalStudents = students.length;
  const today = new Date().toISOString().split("T")[0];
  const todaysAttendance = attendance.filter(a => a.date === today);
  const presentToday = todaysAttendance.filter(a => a.status === 'present' || a.status === 'late').length;
  const attendanceRate = totalStudents > 0 ? (presentToday / totalStudents) * 100 : 0;

  const recentAttendance = attendance
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    .slice(0, 5);
  
  const studentMap = new Map(students.map(s => [s.id, s]));

  return (
    <div className="flex flex-col gap-8">
      <header>
        <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
        <p className="text-muted-foreground">Welcome to your AttendEase dashboard.</p>
      </header>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Total Students
            </CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{totalStudents}</div>
            <p className="text-xs text-muted-foreground">
              Currently enrolled students
            </p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">
              Today's Attendance
            </CardTitle>
            <CalendarCheck className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{presentToday} / {totalStudents}</div>
            <p className="text-xs text-muted-foreground">
              Students marked present or late today
            </p>
          </CardContent>
        </Card>
         <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Attendance Rate</CardTitle>
            <Percent className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{attendanceRate.toFixed(1)}%</div>
            <p className="text-xs text-muted-foreground">
              For today's attendance
            </p>
          </CardContent>
        </Card>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <WeeklyAttendanceChart attendance={attendance} />
        <Card>
            <CardHeader>
                <CardTitle className="flex items-center gap-2">
                    <Activity />
                    Recent Activity
                </CardTitle>
                <CardDescription>The latest attendance records from all classes.</CardDescription>
            </CardHeader>
            <CardContent>
                <div className="space-y-4">
                    {recentAttendance.map(record => {
                        const student = studentMap.get(record.studentId);
                        if (!student) return null;
                        
                        return (
                           <RecentActivityItem key={record.id} record={record} student={student} />
                        )
                    })}
                </div>
            </CardContent>
        </Card>
      </div>
      <InsightsCard />
    </div>
  );
}
