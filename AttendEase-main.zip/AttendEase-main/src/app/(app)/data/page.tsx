
"use client"

import React from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Download, Upload, FileText } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { exportToCsv } from "@/lib/utils";
import { StudentPageClient } from "../students/_components/client-page";
import type { Student } from "@/lib/types";
import { getStudentsAction } from "@/app/actions";


export default function DataPage() {
    const { toast } = useToast();
    const [students, setStudents] = React.useState<Student[]>([]);

    React.useEffect(() => {
        const fetchStudents = async () => {
            const studentData = await getStudentsAction();
            setStudents(studentData);
        };
        fetchStudents();
    }, []);

    const handleExport = async () => {
        try {
            const studentsToExport = await getStudentsAction();
            const rows = [
                ["id", "name", "email", "phone", "class", "parentName", "parentPhone", "dob", "address", "emergencyContactName", "emergencyContactPhone", "photoUrl", "bloodGroup", "erpNumber"],
                ...studentsToExport.map(s => [s.id, s.name, s.email, s.phone, s.class, s.parentName, s.parentPhone, s.dob, s.address, s.emergencyContactName, s.emergencyContactPhone, s.photoUrl, s.bloodGroup, s.erpNumber])
            ];
            exportToCsv("students-export.csv", rows);
            toast({
                title: "Success",
                description: "Student data has been exported.",
            });
        } catch (error) {
            toast({
                title: "Error",
                description: "Failed to export student data.",
                variant: "destructive",
            });
        }
    };
    
    const handleDownloadTemplate = () => {
        const rows = [
             ["id", "name", "email", "phone", "class", "parentName", "parentPhone", "dob", "address", "emergencyContactName", "emergencyContactPhone", "photoUrl", "bloodGroup", "erpNumber"]
        ];
        exportToCsv("students-template.csv", rows);
    }
    
    const handleImport = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (file) {
            // In a real app, you would parse the CSV and update the database.
            // For this demo, we'll just show a success message.
            toast({
                title: "Import Started",
                description: `${file.name} is being processed. This is a demo and data will not be modified.`,
            });
        }
    };


    return (
        <div className="flex flex-col gap-8">
            <header>
                <h1 className="text-3xl font-bold tracking-tight">Data Management</h1>
                <p className="text-muted-foreground">Import, export, and manage student data.</p>
            </header>

            <StudentPageClient students={students} />

            <div className="grid gap-6 md:grid-cols-2">
                <Card>
                    <CardHeader>
                        <CardTitle>Import Student Data</CardTitle>
                        <CardDescription>Upload a CSV file to add or update multiple student profiles at once.</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <Button asChild>
                        <label htmlFor="import-csv">
                            <Upload className="mr-2 h-4 w-4" />
                            Import from CSV
                        </label>
                        </Button>
                        <input type="file" id="import-csv" accept=".csv" className="hidden" onChange={handleImport}/>
                        <p className="text-sm text-muted-foreground">Ensure the CSV file matches the template format.</p>
                        <Button variant="secondary" onClick={handleDownloadTemplate}>
                            <FileText className="mr-2 h-4 w-4" />
                            Download Template
                        </Button>
                    </CardContent>
                </Card>
                <Card>
                    <CardHeader>
                        <CardTitle>Export Student Data</CardTitle>
                        <CardDescription>Download a complete backup of all student profiles in CSV format.</CardDescription>
                    </CardHeader>
                    <CardContent>
                        <Button onClick={handleExport}>
                            <Download className="mr-2 h-4 w-4" />
                            Export All Students
                        </Button>
                        <p className="mt-4 text-sm text-muted-foreground">This file can be used for backups or for editing and re-importing.</p>
                    </CardContent>
                </Card>
            </div>
        </div>
    );
}
