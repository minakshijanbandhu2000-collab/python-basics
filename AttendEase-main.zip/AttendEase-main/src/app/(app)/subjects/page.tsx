import { getSubjectsAction } from "@/app/actions";
import { SubjectClientPage } from "./_components/client-page";

export default async function SubjectsPage() {
  const subjects = await getSubjectsAction();

  return (
    <div className="flex flex-col gap-8">
      <header>
          <h1 className="text-3xl font-bold tracking-tight">Subject Management</h1>
          <p className="text-muted-foreground">
            View, add, edit, and manage all subjects.
          </p>
      </header>
      <SubjectClientPage subjects={subjects} />
    </div>
  );
}
