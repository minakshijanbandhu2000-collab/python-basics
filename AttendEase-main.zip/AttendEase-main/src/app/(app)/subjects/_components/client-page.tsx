"use client";

import React, { useState, useEffect } from 'react';
import { MoreHorizontal, PlusCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { SubjectForm } from "./subject-form";
import type { Subject } from "@/lib/types";
import { deleteSubjectAction, getSubjectsAction } from "@/app/actions";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent } from '@/components/ui/card';
import { useRouter } from 'next/navigation';

interface ClientPageProps {
  subjects: Subject[];
}

export function SubjectClientPage({ subjects: initialSubjects }: ClientPageProps) {
  const { toast } = useToast();
  const router = useRouter();
  const [subjects, setSubjects] = useState(initialSubjects);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [isAlertOpen, setIsAlertOpen] = useState(false);
  const [selectedSubject, setSelectedSubject] = useState<Subject | null>(null);

  useEffect(() => {
    setSubjects(initialSubjects);
  }, [initialSubjects]);

  const refreshSubjects = async () => {
    const freshSubjects = await getSubjectsAction();
    setSubjects(freshSubjects);
    router.refresh();
  }

  const openForm = (subject: Subject | null = null) => {
    setSelectedSubject(subject);
    setIsFormOpen(true);
  };

  const closeForm = () => {
    setIsFormOpen(false);
    setSelectedSubject(null);
    refreshSubjects();
  };
  
  const openDeleteConfirm = (subject: Subject) => {
    setSelectedSubject(subject);
    setIsAlertOpen(true);
  };

  const handleDelete = async () => {
    if (!selectedSubject) return;
    try {
      await deleteSubjectAction(selectedSubject.id);
      toast({
        title: "Success",
        description: "Subject has been deleted.",
      });
      refreshSubjects();
    } catch (error) {
       toast({
        title: "Error",
        description: "Failed to delete subject.",
        variant: "destructive"
      });
    } finally {
        setIsAlertOpen(false);
        setSelectedSubject(null);
    }
  };

  return (
    <>
      <div className="flex items-center justify-end">
        <Button onClick={() => openForm()}>
          <PlusCircle className="mr-2 h-4 w-4" />
          Add Subject
        </Button>
      </div>

      <Card>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Subject Name</TableHead>
                <TableHead>
                  <span className="sr-only">Actions</span>
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {subjects.length > 0 ? subjects.map((subject) => (
                <TableRow key={subject.id}>
                  <TableCell className="font-medium">{subject.name}</TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button aria-haspopup="true" size="icon" variant="ghost">
                          <MoreHorizontal className="h-4 w-4" />
                          <span className="sr-only">Toggle menu</span>
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuLabel>Actions</DropdownMenuLabel>
                        <DropdownMenuItem onSelect={() => openDeleteConfirm(subject)} className="text-destructive">Delete</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              )) : (
                 <TableRow>
                  <TableCell colSpan={2} className="h-24 text-center">
                    No subjects found.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
      
      <Dialog open={isFormOpen} onOpenChange={setIsFormOpen}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Add New Subject</DialogTitle>
            <DialogDescription>
              Fill in the details to create a new subject.
            </DialogDescription>
          </DialogHeader>
          <SubjectForm onFinished={closeForm} />
        </DialogContent>
      </Dialog>
      
      <AlertDialog open={isAlertOpen} onOpenChange={setIsAlertOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you absolutely sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the subject {selectedSubject?.name}.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete}>Continue</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
