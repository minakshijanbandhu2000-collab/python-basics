"use server";

import { generateAttendanceSummaryInsights } from "@/ai/flows/attendance-summary-insights";
import { db } from "@/lib/data";
import { Student } from "@/lib/types";
import { revalidatePath } from "next/cache";

// Data-fetching actions
export async function getStudentsAction() {
  return db.getStudents();
}

export async function getSubjectsAction() {
    return db.getSubjects();
}

export async function getAttendanceAction() {
  return db.getAttendance();
}

export async function getAttendanceByDateAction(date: string) {
  return db.getAttendanceByDate(date);
}

// Insight generation
export async function generateInsightsAction() {
  try {
    const attendanceData = await db.getAttendance();
    const students = await db.getStudents();

    if (attendanceData.length === 0) {
      return { summary: "Not enough attendance data to generate insights. Please record some attendance first." };
    }

    // Convert to CSV string
    const studentMap = new Map(students.map((s) => [s.id, s.name]));
    const header = "student_id,student_name,date,status,subject";
    const rows = attendanceData.map((record) =>
      [
        record.studentId,
        studentMap.get(record.studentId) || 'Unknown',
        record.date,
        record.status,
        record.subject,
      ].join(",")
    );
    const csvString = [header, ...rows].join("\n");
    
    const result = await generateAttendanceSummaryInsights({ attendanceData: csvString });
    return result;
  } catch (error) {
    console.error("Error generating insights:", error);
    return { error: "Failed to generate insights. Please try again." };
  }
}

// Data mutation actions
export async function addStudentAction(data: Omit<Student, 'id' | 'photoUrl'>) {
    const randomPhotoId = Date.now();
    const photoUrl = `https://picsum.photos/seed/${randomPhotoId}/200/200`;
    const studentData = { ...data, photoUrl };
    
    await db.addStudent(studentData);
    revalidatePath("/students");
    revalidatePath("/data");
}

export async function updateStudentAction(id: string, data: Partial<Omit<Student, 'id'>>) {
    await db.updateStudent(id, data);
    revalidatePath("/students");
    revalidatePath(`/students/${id}`);
    revalidatePath("/data");
}

export async function deleteStudentAction(id: string) {
    await db.deleteStudent(id);
    revalidatePath("/students");
    revalidatePath("/data");
}

export async function updateAttendanceAction(studentId: string, date: string, status: 'present' | 'absent' | 'late' | 'excused', subject: string) {
    await db.updateAttendance(studentId, date, status, subject);
    revalidatePath("/attendance");
    revalidatePath("/reports");
    revalidatePath("/dashboard");
}

export async function addSubjectAction(data: { name: string }) {
    await db.addSubject(data);
    revalidatePath("/subjects");
}

export async function deleteSubjectAction(id: string) {
    await db.deleteSubject(id);
    revalidatePath("/subjects");
}
