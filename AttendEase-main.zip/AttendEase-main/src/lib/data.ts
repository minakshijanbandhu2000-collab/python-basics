// @ts-nocheck
// IMPORTANT: We are stringifying and parsing the data to simulate a real database.
// This is a temporary solution for the demo and should not be used in production.
import type { Student, AttendanceRecord } from './types';
import data from './db.json';
import fs from 'fs';
import path from 'path';

// This is a server-only module.
const dbPath = path.join(process.cwd(), 'src', 'lib', 'db.json');

const readData = () => {
  try {
    if (fs.existsSync(dbPath)) {
      const rawData = fs.readFileSync(dbPath, 'utf8');
      return JSON.parse(rawData);
    }
  } catch (error) {
    console.error("Failed to read db.json, returning initial data.", error);
  }
  return data;
};

const writeData = (dataToWrite) => {
  try {
    fs.writeFileSync(dbPath, JSON.stringify(dataToWrite, null, 2), 'utf8');
  } catch (error) {
    console.error("Failed to write to db.json", error);
  }
};

export const db = {
  getStudents: async (): Promise<Student[]> => {
    const currentData = readData();
    return Promise.resolve(JSON.parse(JSON.stringify(currentData.students)));
  },
  getAttendance: async (): Promise<AttendanceRecord[]> => {
    const currentData = readData();
    return Promise.resolve(JSON.parse(JSON.stringify(currentData.attendance)));
  },
  getAttendanceByDate: async (date: string): Promise<AttendanceRecord[]> => {
    const currentData = readData();
    return Promise.resolve(JSON.parse(JSON.stringify(currentData.attendance.filter(a => a.date === date))));
  },
  getStudentById: async (id: string): Promise<Student | undefined> => {
    const currentData = readData();
    return Promise.resolve(JSON.parse(JSON.stringify(currentData.students.find(s => s.id === id))));
  },
  addStudent: async (student: Omit<Student, 'id'>): Promise<Student> => {
    const currentData = readData();
    const newId = `s${Date.now()}`;
    const newStudent: Student = { ...student, id: newId };
    currentData.students.push(newStudent);
    writeData(currentData);
    return Promise.resolve(newStudent);
  },
  updateStudent: async (id: string, data: Partial<Omit<Student, 'id'>>): Promise<Student | null> => {
    const currentData = readData();
    const index = currentData.students.findIndex(s => s.id === id);
    if (index !== -1) {
      currentData.students[index] = { ...currentData.students[index], ...data };
      writeData(currentData);
      return Promise.resolve(currentData.students[index]);
    }
    return Promise.resolve(null);
  },
  deleteStudent: async (id: string): Promise<boolean> => {
    const currentData = readData();
    const index = currentData.students.findIndex(s => s.id === id);
    if (index !== -1) {
      currentData.students.splice(index, 1);
      // Also remove attendance records for this student
      currentData.attendance = currentData.attendance.filter(a => a.studentId !== id);
      writeData(currentData);
      return Promise.resolve(true);
    }
    return Promise.resolve(false);
  },
  updateAttendance: async (studentId: string, date: string, status: 'present' | 'absent' | 'late' | 'excused', subject: string): Promise<boolean> => {
    const currentData = readData();
    let record = currentData.attendance.find(a => a.studentId === studentId && a.date === date && a.subject === subject);
    if (record) {
      record.status = status;
    } else {
      const newRecord: AttendanceRecord = { id: `a${Date.now()}`, studentId, date, status, subject };
      currentData.attendance.push(newRecord);
    }
    writeData(currentData);
    return Promise.resolve(true);
  },
};
