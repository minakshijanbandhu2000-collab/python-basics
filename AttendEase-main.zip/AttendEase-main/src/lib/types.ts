export type Student = {
  id: string;
  name: string;
  email: string;
  phone: string;
  class: string;
  parentName: string;
  parentPhone: string;
  dob: string; // YYYY-MM-DD
  address: string;
  emergencyContactName: string;
  emergencyContactPhone: string;
  photoUrl: string;
  bloodGroup: string;
  erpNumber: string;
};

export type AttendanceStatus = 'present' | 'absent' | 'late' | 'excused';

export type AttendanceRecord = {
  id: string; // Unique ID for the record
  studentId: string;
  date: string; // YYYY-MM-DD
  status: AttendanceStatus;
  subject: string;
};
