'use server';

/**
 * @fileOverview AI-powered attendance insights flow.
 *
 * - generateAttendanceSummaryInsights - A function that generates insights from attendance data.
 * - AttendanceSummaryInsightsInput - The input type for the generateAttendanceSummaryInsights function.
 * - AttendanceSummaryInsightsOutput - The return type for the generateAttendanceSummaryInsights function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const AttendanceSummaryInsightsInputSchema = z.object({
  attendanceData: z
    .string()
    .describe(
      'Student attendance data in CSV format, including student ID, name, date, attendance status, and subject.'
    ),
});
export type AttendanceSummaryInsightsInput = z.infer<
  typeof AttendanceSummaryInsightsInputSchema
>;

const AttendanceSummaryInsightsOutputSchema = z.object({
  summary: z
    .string()
    .describe(
      'A summary of insights from the attendance data, highlighting trends, potential issues, and areas of concern.'
    ),
});
export type AttendanceSummaryInsightsOutput = z.infer<
  typeof AttendanceSummaryInsightsOutputSchema
>;

export async function generateAttendanceSummaryInsights(
  input: AttendanceSummaryInsightsInput
): Promise<AttendanceSummaryInsightsOutput> {
  return attendanceSummaryInsightsFlow(input);
}

const attendanceSummaryInsightsPrompt = ai.definePrompt({
  name: 'attendanceSummaryInsightsPrompt',
  input: {schema: AttendanceSummaryInsightsInputSchema},
  output: {schema: AttendanceSummaryInsightsOutputSchema},
  prompt: `You are an AI assistant that analyzes student attendance data and generates insights for teachers.

  Analyze the following attendance data and provide a concise summary of key trends, potential issues, and areas of concern. Highlight any students with consistently poor attendance or classes with unusual attendance patterns.

  Attendance Data:
  {{attendanceData}}`,
});

const attendanceSummaryInsightsFlow = ai.defineFlow(
  {
    name: 'attendanceSummaryInsightsFlow',
    inputSchema: AttendanceSummaryInsightsInputSchema,
    outputSchema: AttendanceSummaryInsightsOutputSchema,
  },
  async input => {
    const {output} = await attendanceSummaryInsightsPrompt(input);
    return output!;
  }
);
