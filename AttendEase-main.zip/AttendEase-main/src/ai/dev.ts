import { config } from 'dotenv';
config();

import '@/ai/flows/attendance-summary-insights.ts';