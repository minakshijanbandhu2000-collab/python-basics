# **App Name**: AttendEase

## Core Features:

- Student Profiles: Create and manage student profiles including ID, name, email, phone, class, parent info, DOB, address, emergency contacts and photo.
- Daily Attendance Marking: Mark daily attendance with visual status indicators and class filtering.
- Monthly Attendance Reports: Generate detailed monthly percentage reports with color-coded indicators, class-wise and overall statistics.
- CSV Data Import/Export: Import and export student and attendance data using CSV files.
- Generate insight summary: Leverage AI to analyze student attendance data and generate brief summaries that provides tools and insights of attendance trends, highlighting potential areas of concern. The LLM tool determines whether those trends actually suggest any areas of concern, based on factors that may vary, student to student.  

## Style Guidelines:

- Primary color: Indigo (#4B0082) to convey professionalism and trust.
- Background color: Light gray (#F0F0F0) for a clean and neutral backdrop.
- Accent color: Teal (#008080) for highlighting key actions and data points, offering a refreshing contrast.
- Body and headline font: 'PT Sans', a versatile sans-serif font suitable for both headlines and body text, maintaining readability and a modern feel.
- Use clear, simple icons to represent attendance status, report types, and data functions.
- Maintain a tab-based layout for clear sectioning (Student Management, Attendance Tracking, Reports, Data Management), with intuitive forms.
- Subtle transitions for page loading and form interactions.